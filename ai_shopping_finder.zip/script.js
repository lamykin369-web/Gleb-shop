
function searchItem() {
    const url = document.getElementById('url').value.trim();
    const results = document.getElementById('results');
    if (!url) {
        results.innerHTML = "<p>Пожалуйста, вставь ссылку.</p>";
        return;
    }

    // Placeholder AI logic
    const query = encodeURIComponent("товар из видео");
    results.innerHTML = `
      <a href="https://www.ozon.ru/search/?text=${query}" target="_blank">Искать на Ozon</a>
      <a href="https://market.yandex.ru/search?text=${query}" target="_blank">Искать на Яндекс Маркете</a>
      <a href="https://www.aliexpress.ru/wholesale?SearchText=${query}" target="_blank">Искать на AliExpress</a>
    `;
}
